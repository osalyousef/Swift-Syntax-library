import Cocoa
// Little library for swift syntax , I mostly learned from https://www.hackingwithswift.com/

/*let C = 20.2
let F = ((C*9.0)/5) + 32
print("C is \(C) Converted to F = \(F)")
 */

// arrays
/*
var animals = ["Cat" , "Dog" , "Lion"]
let ages = [4 , 13 , 10]
print (animals[0])
print (ages[0])
animals.append("Snake")
print (animals[3]) // we changed array size
print(animals.count)
animals.remove(at: 3)
print(animals.count)
animals.contains("Bear")
animals.sorted()
animals.append("Ant")
animals.sorted()
let presidents = ["Bush", "Obama", "Trump", "Biden"]
let reversedPresidents = presidents.reversed()
print(reversedPresidents)
*/


// Dictionaries

/*
let employee = [
    "name": "Osama Alyousef",
    "Job": "Programmer",
    "Department:": "CS"
]
print(employee["name" , default: "Uknown"])
// set 2 attributes together
var student = [String : Int] ()
student["OSAMA Alyousef" , default: 0] = 441109070 
print(student["OSAMA Alyousef"])
student.removeAll()
*/

// Sets
/*
var people = Set(["Osama" , "Omar" , "Rayan"])
print(people) // doesnt care about order , dont accept duplicants
people.insert("Aboleth") // use insert not append
print(people) // why use sets? , faster than arrays
*/


// enums
/*
enum Days {
case Sunday  , Monday , Tuesday , Wendesday , Thursday
}
var Day1 = Days.Sunday
Day1 = .Thursday
Day1 = .Sunday
print(Day1)
*/

//

//  type annotations
    /*
var name: String = "OS" // normal declaration
let ID: Int = 441109070 // same but for int
let isAuth: Bool = true // same
var user: [String : Int] = ["Oskayal": 441109080]// dictonairy
var books: Set<String> = Set(["HUNGER GAMES"]) // sets
var emp: [String] = [] // Empty array of strings
let username: String // empty declaration
username = "oskayal"// further
*/


//recap
    /*
We’ve gone beyond simple data types now, and started looking at ways to group them together and even create our own using enums. So, let’s recap:

Arrays let us store lots of values in one place, then read them out using integer indices. Arrays must always be specialized so they contain one specific type, and they have helpful functionality such as count, append(), and contains().
Dictionaries also let us store lots of values in one place, but let us read them out using keys we specify. They must be specialized to have one specific type for key and another for the value, and have similar functionality to arrays, such as contains() and count.
Sets are a third way of storing lots of values in one place, but we don’t get to choose the order in which they store those items. Sets are really efficient at finding whether they contain a specific item.
Enums let us create our own simple types in Swift so that we can specify a range of acceptable values such as a list of actions the user can perform, the types of files we are able to write, or the types of notification to send to the user.
Swift must always know the type of data inside a constant or variable, and mostly uses type inference to figure that out based on the data we assign. However, it’s also possible to use type annotation to force a particular type.
Out of arrays, dictionaries, and sets, it’s safe to say that you’ll use arrays by far the most. After that comes dictionaries, and sets come a distant third. That doesn’t mean sets aren’t useful, but you’ll know when you need them!
*/



// combine set with array
/*
 let movies: [String] = ["Dark knight" , "Meow" , "Fight Club" , "Fight Club"]
 print(movies[0])
 movies.count
 let uniqueMovies = Set(movies)
 print(uniqueMovies)
 */


// IF
/*
let student: [String: Int] = ["OS" : 83 , "MIMI" : 74]
if let score = student["OS"] , score > 70 {
    print ("PASS")
}
else {
    print("FAIL")}

let age = 18
if age <= 18 {
    print("You're safe from being molested by os")
}
else {
    print ("Molesteration is comin")
}
let ourName = ""
let friendName = "Osama Alyousef"

if ourName < friendName {
    print("It's \(ourName) vs \(friendName)")
}

if ourName > friendName {
    print("It's \(friendName) vs \(ourName)")
}
if ourName.isEmpty {
    print("Empty")
}
enum parkingTypes {
    case free , regular , premium
}
let parkingPrice = parkingTypes.premium
if parkingPrice == .free {
    print("its free")
}
else if parkingPrice == .premium || parkingPrice == .regular{
    print("Its not free")
}
*/


//Switch
/*
enum weather {
    case sunny , raining , cloudy , snowing , glow
}
let predect = weather.glow
switch predect {
case .sunny:
    print("Sunny weather")
case .cloudy:
    print("Cloudy weather")
case .raining:
    print("Raining weather")
case .snowing:
    print("Snowy weather")
default:
    print("Unknown weather")
}
let day = 5
switch day {
case 5:
    print("Five")
    fallthrough
case 4:
    print("Four")
    fallthrough
case 3:
    print("Three")
    fallthrough
case 2:
    print("Two")
    fallthrough
case 1:
    print("One")
    fallthrough
default:
    print("Zero")
    }
*/


//Ternary
/*
let age = 19
let drinkAge = age >= 18 ? "Legal"/* True condition*/ : "Not legal"
// follow WTF : WHAT , TRUE , FALSE
let names: [String] = ["OS","Seetah" , "Latifah"]
let familyNumber = names.isEmpty ? "No family" : "Family number: \(names.count)"
*/


// For loops
/*
let platforms: [String] = ["IOS" , "MACOS" , "WINDOWS"]
for os in platforms {
    print("Swift work on \(os)")
}
for i in 1..<12 {
    print("The \(i) times table:")

    for j in 1...12 {
        print("  \(j) x \(i) is \(j * i)")
    }

    print()
}

var movie2: String = "Fight club is the "
for _ in 1..<5 {
    movie2 += " best"
}
print(movie2)
*/



//while loop]
/*
// while loops are really useful when you just don’t know how many times the loop will go around.
let id = Double.random(in: 0...1) // And this creates a random decimal between 0 and 1:
var roll = 0
while roll != 6 {
    roll = Int.random(in: 1...6)
    print("Rolled: \(roll)")
}
    print("Move a piece")
*/




// TEST D3
/*
for i in 1...100 {
    if i.isMultiple(of: 3) && i.isMultiple(of: 5){
        print ("FizzBuzz")
    }
    else if i.isMultiple(of: 3)
    {
        print ("Fizz")
    } else if i.isMultiple(of: 5){
        print ("Buzz")
    }
    else {
        print(i)
    }
}
*/




//functions
/*
func myName(Name: String) {
    print("My name is \(Name)")
}
myName(Name: "Meow")

func diceRoll() -> Int {
    return Int.random(in: 1...6)
}
let result = diceRoll()
print(result)

func sortStrings(string1: String , string2: String) -> String {
    let combinedString = string1 + string2
    let sortedString = combinedString.sorted()
    return String(sortedString)
}
let s1: String = "bcd"
let s2: String = "agk"
print(sortStrings(string1: s1, string2: s2))
func pythagoras(a: Double, b: Double) -> Double {
 return sqrt(a*a + b*b)
}

let c = pythagoras(a: 3, b: 4)
print(c)

*/




//Tuples
/*
func getUser() -> (fName: String , lName: String) {
    (fName: "OSAMA" , lName: "Alyousef")
}
let user = getUser()
print("First name: \(user.fName) , Last name: \(user.lName)")
*/


//error handling
/*
enum passwordError: Error {
    case short , obvius , empty
}
func checkPassword (_ password: String) throws -> String {
    if password.isEmpty {
        throw passwordError.empty
    }
    if password.count <= 5 {
        throw passwordError.short
    }
    if password == "Ao112233" {
        throw passwordError.obvius
    }
    if password.count > 5 {
       return "ok"
    }
    else {
        return "Exceleent"
    }
}
// in real projects do this
let string = "123e45"
do {
    let result = try checkPassword(string)
    print("Password rating: \(result)")
} catch passwordError.short {
    print("Password too short ")
} catch passwordError.obvius {
    print("Password too obvious ")
} catch passwordError.empty {
    print("Password empty ")
}
catch {
    print("undefined error ")
}
*/



//checkpoint 4
/*
    enum rootErrors: Error {
    case outOfBound , noRoot
    }

    func getRoot ( x: Int) throws -> Int {
        var result = 1
        var i = 1
        if 1 > x {
            throw rootErrors.outOfBound
        } else if  x >= 10_000 {
            throw rootErrors.outOfBound
        }
        while result <= x  {
            i = i + 1
            result = i * i
        }
    return i - 1
    }
    do {
        let result1 = try getRoot(x: 5)
        print (result1)
    }
        catch rootErrors.outOfBound {
            print("out of bounds")
        } catch rootErrors.noRoot {
            print("No root")
        }
*/



//Closures
/*
let sayHello = { (name:String) -> String in
    "Hello \(name)"
}
print(sayHello("OS"))
func getStudentID(id: String) -> String {
    if id.hasPrefix("44") {
        return "Student is 2022 class"
    }
    else { return "Student is not 2022 class"}
    
}
let s441109070Data: (String) -> String = getStudentID
let s441109070 = s441109070Data("431109070")
print (s441109070)

let student: [String] = ["Osama" , "Rayan" , "Ahmed"] // osama gpa is 4.2 , ahmed is 4.0 , rayan is 3.4
let studentGpa: [Double] = [3.2 , 4.1 , 4.8]

let studentByGpa = student.sorted(by: { (s1: String , s2: String) -> Bool in
    if s1 == "Osama" {
        return true
    } else if s2 == "Osama" || s2 == "Rayan" {
        return false
    }
    
    return s1 > s2
})

print(studentByGpa)
*/





// trailing closure
/*
let family: [String] = ["Osama" , "Seetah" , "Latifa"]

let momFirst = family.sorted(by: { (f1: String , f2: String) -> Bool in
    if f1 == "Seetah" {
        return true
    } else if f2 == "Seetah" {
        return false
    }
    return f1 > f2
})
print(momFirst)
// to use trailing in this colsure follow:
let family_: [String] = ["Latifa" , "Seetah" , "Osama"]
let broFirst = family_.sorted { f1_ , f2_ in
    if f1_ == "Osama" {
        return true
    } else if f2_ == "Osama" {
        return false
    }
    return f1_ > f2_
}
print(broFirst)

// to use reverse just do this
let reverseFam = family_.sorted {$0 > $1}
print(reverseFam)

let family_2: [String] = ["Latifa" , "Seetah" , "Osama" , "Hoor"]
let oOnly = family_2.filter() { $0.hasPrefix("O")}
print(oOnly)

let upperCasedFam = family_2.map() { $0.uppercased() }
print(upperCasedFam)
*/



// func accept other func
/*
func makeArray(size: Int , using genreator: () -> Int) -> [Int] {
    var number = [Int]()
    for _ in 0..<size {
        let newNum = genreator()
        number.append(newNum)
    }
    return number
}
let rolls = makeArray(size: 30) {
    Int.random(in: 1...20)
}
print(rolls)

// common syntax
func printWelcome(first: () -> Void , Second:() -> Void , Third:() -> Void) -> Void {
    print("Welcome ! (name) ")
first()
    print("Sign up / login")
Second()
    print("login: enter email password")
Third()
    print("Sign up: email password name")
}
*/


// CHP 5
/*
let luckyNumbers: [Int] = [7,4 ,38,21,16,15,12,33,31,49]
let oddLuckyNum = 
luckyNumbers.filter() { $0 % 2 != 0}
.sorted() {$0 < $1}
.map( ) { "\($0) is a lucky number " }
for i in oddLuckyNum {
    print(i)
}
*/



// structs
/*
struct Students {
    let sID: Int
    let sName: String
    var sGPA: Double = 4.0
    
    func studentInfo() {
        print("Name: \(sName) , ID: \(sID) , GPA: \(sGPA)")
    }
    func gradeSet(grade: String) -> Double  {
        if grade == "A+" {
            os.sGPA = os.sGPA + 0.1
        } else {
            os.sGPA = os.sGPA  - 0.1
        }
        return (os.sGPA * 1000).rounded() / 1000
    }
}

var os = Students(sID: 441109070, sName: "Osama Alyousef" , sGPA: 4.13)
os.studentInfo()
print("Gpa after grade: \(os.gradeSet(grade: "A"))")

var latifah = Students(sID: 8765432, sName: "Latifa Alyousef" )
latifah.studentInfo()

struct Employee {
    let name: String
    var vacationAllocated = 14
    var vacationTaken = 0
    
    var vacationRemaining: Int {
        get {
            vacationAllocated - vacationTaken
        }
        set {
            vacationAllocated = vacationTaken + newValue
        }
    }
}
var meow = Employee(name: "OS" , vacationAllocated: 14 )
meow.vacationTaken += 4
meow.vacationRemaining = 6
print(meow.vacationAllocated)
 
 
 
 struct Book {
     let title: String
     let pageCount: Int
     let readingHours: Int

     init(title: String, pageCount: Int) {
         self.title = title
         self.pageCount = pageCount
         self.readingHours = pageCount / 50
     }
 }
 
*/


//did set did get
/*
struct Hotel {
    var residents = 0 {
        didSet {
            print("Residents now are: \(residents)")
        }
    }
    var rooms = [String] () {
        willSet {
            print("Rooms available now: \(rooms)")
            print("Rooms available next: \(newValue)")
        }
        didSet {
            print("There is \(rooms.count) available")
            print("Previously there was \(oldValue)")
        }
    }
}
var hotel = Hotel()
hotel.residents += 3
hotel.residents -= 1
hotel.rooms.append("107")
hotel.rooms.append("103")
*/


// custom initalizers / constructors
/*
struct Animal {
    let name: String
    let cage: Int
    init(name: String) {
        self.name = name
        cage = Int.random(in: 1...32)
    }
}
let dog = Animal(name: "Leo")
print(dog.cage ) // Just remember the golden rule: all properties must have a value by the time the initializer ends. 
                // If we had not provided a value for number inside the initializer, Swift would refuse to build our code.
*/


//limit acceses
/*
//Use private for “don’t let anything outside the struct use this.”
//Use fileprivate for “don’t let anything outside the current file use this.”
//Use public for “let anyone, anywhere use this.”
struct user {

    private var password: String
    mutating func passwordCheck (password: String) -> Bool {
        if password.isEmpty  {
            print("Cannot have empty password")
            return false
        } else {
            print("Enter Password: ")
            return true
        }
    }
    }

*/




//Static
/*
//  static best use when you use it as example or common info like app version
struct movie {
    static var moviesNum: Int = 0
    static func add(movieName: String) {
        print("ADDED: \(movieName)")
        moviesNum += 1
    }
}
movie.add(movieName: "Fight club")
print(movie.moviesNum)
*/



// chp6
/*
struct Car {
    let name = "Accent"
    let model = 2016
    let seatsNumber = 6
    var currentGear = 1
    mutating func gearChange(speed: Int ) -> Int {
        if  speed > 20 && speed <= 30 {
            currentGear = 2
            print("Current gear: \(currentGear)")
            return currentGear
        } 
        else if  speed > 30 && speed <= 50 {
            currentGear = 3
            print("Current gear: \(currentGear)")
            return currentGear
        }   
        else if  speed > 50 {
            currentGear = 4
            print("Current gear: \(currentGear)")
            return currentGear
        } else {
            return 0
        }
    }
}
var car = Car()
car.gearChange(speed: 50)
*/



//CLASSES
/*
class  Cat {
    let momName: String
    let dadName: String
    init(momName: String, dadName: String, sons: Int = 0) {
        self.momName = momName
        self.dadName = dadName
        self.sons = sons
    }
    var sons = 0 {
        didSet {
            print("Son count is \(sons)")
        }
    }
    func display() {
        print("My dad is: \(dadName) , My mom name is: \(momName) and I am a female ")
    }
    
}

class catChild: Cat {
    override func display() {
        print("My dad is: \(dadName) , My mom name is: \(momName) and i am a male")
    }

}

let son = catChild(momName: "Stella", dadName: "Leo")
let daughter = Cat(momName: "Emily", dadName: "Leo") // leo is a player
son.display()
daughter.display()
*/



// classes init
/*
class Vehicle {
    let isTruck: Bool
    init(isTruck: Bool) {
        self.isTruck = isTruck
    }
}
class Car: Vehicle {
    let fuelPetrol: Bool
    init(fuelPetrol: Bool , isTruck: Bool) {
        self.fuelPetrol = fuelPetrol
        super.init(isTruck: isTruck)
    }
}
let Accent = Car(fuelPetrol: true, isTruck: false)
*/



// classes copy
/*
class User{
    var username = "oskayal"
    func copy() -> User {
         let user = User()
         user.username = username
         return user
     }
 }

var user1 = User()
print(user1.username)
var user2 = user1
user2.username = "Khaled_Abdulrahman"
print(user1.username)
print(user2.username)
*/


// Classes d-init ( destructor )
/*
class Citizen {
    let nationalId: Int
    init(nationalId: Int) {
        self.nationalId = nationalId
        print("\(nationalId): I am Alive")
    }
    deinit {
        print("\(nationalId): I am Dead ")
    }
}

for i in 1...2 {
    let citizen1 = Citizen(nationalId: i)
    print("\(citizen1.nationalId): I am proud saudi")
}

var citizens = [Citizen]()
print("-----------------------------------------------")
for i in 1...3 {
    let citizen2 = Citizen(nationalId: i)
    print("\(citizen2.nationalId): I am Array of citizens")
    citizens.append(citizen2)
}
print("Loop is finished!")
citizens.removeAll()
print("Array is clear!")
*/



// variables inside classes
/*
class User {
    var name = "Paul"
}

var user = User()
user.name = "Taylor"
user = User()
print(user.name)
*/



// CHP7
/*
class Animal {
    var legs = 4
    init(legs: Int = 4) {
        self.legs = legs
    }
}
class Cat: Animal {
    var isTame: Bool
    func speak() {
        print("Meow (But in a cat way)")
    }
    init(isTame: Bool , legs: Int ) {
        self.isTame = isTame
        super.init(legs: legs)
    }
}
class Dog: Animal {
    func speak() {
        print("Meow")
    }
}
class Corgi: Dog {
    override func speak() {
        print("Ruff Ruff")
    }
}
class Poodle: Dog {
    override func speak() {
        print("Ruff Ruff (But loudly)")
    }
}

class Persian: Cat {
    override func speak() {
        print("Meow (Cutely)")
    }
}
class Lion: Cat {
    override func speak() {
        print("RAWWWRRRR")
    }
}
*/



// Protocols

/*
protocol Vehicle {
    var name: String { get }
    var currentPassengers: Int { get set }
    func estimateTime(for distance: Int) -> Int
    func travel(distance: Int)
}
struct Car: Vehicle {
    func estimateTime(for distance: Int) -> Int {
        distance / 50
    }

    func travel(distance: Int) {
        print("I'm driving \(distance)km.")
    }

    func openSunroof() {
        print("It's a nice day!")
    }
    let name = "Car"
    var currentPassengers = 1
}
struct Bicycle: Vehicle {
    func estimateTime(for distance: Int) -> Int {
        distance / 10
    }

    func travel(distance: Int) {
        print("I'm cycling \(distance)km.")
    }
    let name = "Bicycle"
    var currentPassengers = 1
}


let car = Car()
let bike = Bicycle()
func getTravelEstimates(using vehicles: [Vehicle], distance: Int) {
    for vehicle in vehicles {
        let estimate = vehicle.estimateTime(for: distance)
        print("\(vehicle.name): \(estimate) hours to travel \(distance)km")
    }
}
getTravelEstimates(using: [car,bike], distance: 150)
*/



// opaque return
/*
 func getHeadsOrTails() -> Int {
 Int.random(in: 1...2)
 }
 func lieDetector() -> Bool {
 Bool.random()
 }
 // print(getHeadsOrTails() == lieDetector())
 1// this would be a no no because different types cant be equal
 
 func getHeadsOrTails_() -> some Equatable {
 Int.random(in: 1...2)
 }
 
 func lieDetector_() -> some Equatable {
 Bool.random()
 }
 print(lieDetector_() == lieDetector_())
 print(getHeadsOrTails_() == getHeadsOrTails_())
 */



// Extensions
/*
var qoute = "   CUT YOUR COAT ACCORDING TO YOUR CLOTH                       "
let qouteTrimmed = qoute.trimmingCharacters(in: .whitespacesAndNewlines)
print(qoute)
print(qouteTrimmed)
// calling this is wordy so lets make an extension
extension String {
    func trimmed() -> String {
        self.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    var lines: [String] {
        self.components(separatedBy: .newlines)
    }
}
var newQoute = "        A bad workman always blames his tools "
let newQouteTrimmed = newQoute.trimmed()
print("-----------------------------------")
print(newQoute)
print(newQouteTrimmed)
print("-----------------------------------")
let lyrics = """
But I keep cruising
Can't stop, won't stop moving
It's like I got this music in my mind
Saying it's gonna be alright
"""
print(lyrics.lines.count)
*/




//protocol extensions https://www.hackingwithswift.com/quick-start/beginners/how-to-get-the-most-from-protocol-extensions
/*
extension Collection { // collection includes Arrays , Sets , Dictonaries
    var isNotEmpty: Bool {
        isEmpty == false
    }
}
protocol UserName {
    var username: String {get}
    func greet()
}
extension UserName {
    func greet() {
        print("Welcome \(username)")
    }
}
struct User: UserName {
    let username: String
}
let user1 = User(username: "oskayal")
user1.greet()
*/




//chp 8
/*
protocol Building {
    var room: Int {get}
    var price: Int {get}
    var agentName: String {get}
    func salesSummary()
}
struct House: Building {
    let agentName = "Susan"
    var room = 5
    var price = 500_000
    func salesSummary() {
        print("Agent name: \(agentName) , Rooms: \(room) , Price: \(price)")
    }
}
struct Office: Building {
    let agentName = "Mike"
    var room = 2
    var price = 100_000
    func salesSummary() {
        print("Agent name: \(agentName) , Rooms: \(room) , Price: \(price)")
    }
}
let o1 = Office()
o1.salesSummary()
let h1 = House()
h1.salesSummary() // line 1000 yaaaay
*/





// optionals
/*
let opposite = [
    "Batman": "Superman" ,
    "Saul Goodman": "lalo salamanca"
]
let jokerOpposite = opposite["Bruce wayne"] // So theres no bruce wayne in the dictoniary above .. to fix this we provide optional

if let batmanOpposite = opposite["Batman"] {
    print("Batman opposite is \(batmanOpposite)")
}
let username: String? = nil
if let name = username {
    print("Username: \(name)")
} else {
    print("Empty !")
}


func square(num: Int) -> Int {
  return num * num
}
var num: Int? = nil
// print(square(num: num)) Swift will refuse to build that code, because the optional integer needs to be unwrapped
if let num = num { // you can unwrap with same name
    print(square(num: num))
}
*/




//OPTIONALS WITH GUARD
/*
 func printSquaew(for number: Int?) {
 guard let number = number else {
 print("Missing input")
 return
 }
 print("\(number) x \(number) = \(number * number) ")
 }
 
 //var myVar: Int? = 3
 
 //if let unwrapped = myVar {
 //  print("Run if myVar has a value inside")
 //}
 
 // guard let unwrapped = myVar else {
 //  print("Run if myVar doesn't have a value inside")
 //}
 func printSquare(of number: Int?) {
 guard let number = number else {
 print("Missing input")
 
 // 1: We *must* exit the function here
 return
 }
 
 // 2: `number` is still available outside of `guard`
 print("\(number) x \(number) is \(number * number)")
 }
 // So: use if let to unwrap optionals so you can process them somehow, and use guard let to ensure optionals have something inside them and exit otherwise.
 */




//optionals with nil coalescin
/*
let players = ["Messi" , "Ronaldo" , "Salem"]
let favorite = players.randomElement() ?? "None" // ?? represent nil coalescing

struct Health {
    var Hp: Int?
    var inventory: Int
}
let health = Health(Hp: nil, inventory: 21)
*/




//handle multiple optional
/*

let family = ["Seetah" , "Latifah" , "Monirah" , "Osama"]
let choose = family.randomElement()?.uppercased() ?? "NO one"
print("Next family member: \(choose)")

struct Book {
    let title: String
    let author: String? // might have an author or anynomus
}
var book: Book? = nil
let author = book?.author?.first?.uppercased() ?? "Anonymous"
// “if we have a book, and the book has an author, and the author has a first letter, then uppercase it and send it back, otherwise send back A”.
print(author)
*/




// Handle function failures with optionals
/*
enum UserError: Error {
case userNotAvailable , networkFailed
}
func getUsername(username: String) throws -> String {
    throw UserError.networkFailed
}
if let user = try? getUsername(username: "oskayal") {
    print("User: \(user)")
}
 //  If you want to know exactly what error happened then this approach won’t be useful
let user_ = (try? getUsername(username: "oskayal")) ?? "Anon"
print(user_)
*/




// CHP9
//func ran(array: [Int]?) -> Int { array?.randomElement() ?? Int.random(in: 1...100)}
